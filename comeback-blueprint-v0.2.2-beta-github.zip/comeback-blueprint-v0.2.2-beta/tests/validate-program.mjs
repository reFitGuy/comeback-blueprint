import fs from 'node:fs';
import assert from 'node:assert/strict';

const root = new URL('../', import.meta.url);
const program = JSON.parse(fs.readFileSync(new URL('data/program.json', root)));
const library = JSON.parse(fs.readFileSync(new URL('data/exercises.json', root)));
const exercises = library.exercises;

assert.deepEqual(program.weeks, [...Array(13).keys()]);
assert.deepEqual(program.days.map(d => d.id), ['d1','d2','d3','d4','recovery']);
assert.equal(program.days[0].groups[0].pair, 'Pair A');
assert.equal(program.days[2].groups[0].pair, 'Pair A');
assert.ok(!program.days[1].groups.some(g => g.pair));
assert.ok(!program.days[3].groups.some(g => g.pair));
assert.equal(exercises.pullup.vars[0].name, 'L-Sit Pull-Up');

const names = Object.values(exercises).flatMap(e => e.vars.map(v => v.name.toLowerCase()));
assert.ok(!names.some(n => n.includes('weighted pull-up')));
assert.ok(!names.some(n => n.includes('weighted dip')));

for (const day of program.days.filter(d => !d.recovery)) {
  for (const id of day.groups.flatMap(g => g.items)) {
    assert.ok(exercises[id], `Missing exercise definition: ${id}`);
  }
}

console.log('Comeback Blueprint guardrails validated.');
