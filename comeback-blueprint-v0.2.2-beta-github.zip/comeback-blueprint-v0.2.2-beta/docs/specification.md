# Comeback Blueprint v0.1.0 Specification

## Product purpose

Comeback Blueprint is a mobile-first training log for one fixed comeback program. It is not a general workout generator. The software presents, records, and explains the program without rewriting it.

## Program guardrails

1. The weekly split is Upper A, Lower A, Upper B, Lower B.
2. Upper A and Upper B retain their antagonist push/pull pairings.
3. Every exercise has one untracked warm-up round and exactly two tracked working sets.
4. Upper-body work remains calisthenics-only throughout Weeks 0–12.
5. Weighted pull-ups and weighted dips are excluded.
6. Lower-body equipment is introduced gradually through explicit week unlocks.
7. The athlete may manually choose any currently available variation.
8. Coaching is advisory and never changes a workout or variation automatically.
9. Progression status is scoped to the current phase and current variation.
10. The original exercise order remains fixed.

## Program phases

- Week 0: Reactivation
- Weeks 1–4: Foundation
- Weeks 5–8: Accumulation
- Weeks 9–12: Intensification

## Progression rules

- **Ready:** both working sets hit the phase ceiling at effort 3 or easier for two consecutive sessions.
- **Still hard:** hitting the ceiling at effort 4–5 does not count as mastery.
- **Fast track:** the first recorded session can clear immediately when both sets hit the ceiling at effort 3 or easier.
- **Reset:** changing phase or variation resets confirmation history for that scope.
- **Manual authority:** recommendations never switch a variation for the user.

## Storage

Workout state is stored locally on the device. Export and import are provided for manual backup. No account or cloud synchronization is claimed.

## Acceptance tests

A release is acceptable only when all of the following are true:

- Weeks 0–12 are selectable.
- All four strength days and Off-Day Recovery are available.
- Upper-day pair labels and pair-level rest instructions are visible.
- Lower days are not falsely paired.
- Every exercise logs exactly two working sets with reps/time and effort.
- Warm-up work is shown but not logged.
- L-sit pull-up is the initial pull-up variation.
- No weighted pull-up or weighted dip appears anywhere.
- Manual variation selection works and respects week unlocks.
- Data survives a page reload.
- Export/import works.
- Readiness and progression messages do not alter the program automatically.
