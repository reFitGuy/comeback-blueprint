# Changelog

## v0.2.1 Beta
- Corrected guided antagonist-pair order.
- Added automatic 90-second pair rest screen.
- Changed guided logging to one working set at a time.


## v0.2.0 Beta — CB-2026.07.001
- Redesigned the app around today's workout.
- Added guided workout mode.
- Added dedicated Progress, Exercises, and Settings views.
- Added visible version/build information.
- Preserved the validated program engine and local data storage.

## v0.1.0
- Initial data-driven foundation and validated workout engine.

## v0.2.2 Beta
- Fixed iPhone portrait layout and horizontal overflow.
- Added stable rep steppers and immediate persistence.
- Added explicit saved-local confirmation and timestamp.
